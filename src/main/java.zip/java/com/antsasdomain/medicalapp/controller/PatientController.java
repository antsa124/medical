package com.antsasdomain.medicalapp.controller;

import com.antsasdomain.medicalapp.dto.prescriptionDTO.PrescriptionResponseForUserDTO;
import com.antsasdomain.medicalapp.dto.patientDTO.PatientDTO;
import com.antsasdomain.medicalapp.dto.patientDTO.PatientResponseDTO;
import com.antsasdomain.medicalapp.dto.patientDTO.PatientUpdateDTO;
import com.antsasdomain.medicalapp.model.Patient;
import com.antsasdomain.medicalapp.service.PatientService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class PatientController {

    private PatientService patientService;

    private static final Logger logger = LoggerFactory.getLogger(PatientController.class);

    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    @GetMapping
    public ResponseEntity<List<PatientResponseDTO>> getAllUsers() {
        logger.info("Fetch all users from database...");
        List<PatientResponseDTO> userDTOs = patientService.getAllUsers();
        logger.info("Fetched all users from database...");
        return new ResponseEntity<>(userDTOs, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Integer id) {
        logger.info("Fetch user by id from database...");
        PatientResponseDTO user = patientService.getUserById(id);
        if (user != null) { // User is present
            logger.info("Fetched user {} by ID.", user.getUsername());
            return new ResponseEntity<>(user, HttpStatus.OK);
        } else {
            logger.info("Fetched user by ID {} not found.", id);
            return new ResponseEntity<>(
                    Map.of("error", "User with ID " + id + " not found."),
                    HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<?> createUser(@Valid @RequestBody PatientDTO userDTO) {
        logger.info("Create new user...");
        ResponseEntity<?> responseEntity = patientService.savePatient(userDTO);
        logger.info("User created");
        return responseEntity;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteUser(@PathVariable Integer id) {
        logger.info("Delete user by ID: {}", id);
        PatientResponseDTO user = patientService.getUserById(id);
        if (user != null) { // user is present
            patientService.deleteUserById(id);
            return new ResponseEntity<>(Map.of("message", "User deleted successfully"), HttpStatus.OK);
        } else {
            logger.info("User with ID {} not found.", id);
            return new ResponseEntity<>(Map.of("error", "User with ID " + id + " not found."),
                    HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(
            @Valid @RequestBody PatientUpdateDTO patientUpdateDto, @PathVariable Integer id) {
        Patient user = patientService.getUserWithId(id);

        logger.info("Updating User with ID: {}", id);

        if (user != null) { // it tells if user is present in database
            logger.info("Updating User with ID {}", id);
            PatientResponseDTO updatedUser = patientService.updateUser(user, patientUpdateDto);
            logger.info("Updated User with ID {}", id);
            return ResponseEntity.ok(updatedUser);
        } else {
            logger.error("User with ID {} not found.", id);
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "User with ID " + id + " not found."));
        }
    }

    @GetMapping("/{id}/prescriptions")
    public ResponseEntity<?> getPrescriptionsByUserId(@PathVariable Integer id) {
        logger.info("Fetch user's prescriptions by user ID: {}", id);
        List<PrescriptionResponseForUserDTO> allPrescriptionsById =
                patientService.findAllPrescriptionsById(id);
        if (allPrescriptionsById != null && !allPrescriptionsById.isEmpty()) {
            logger.info("Prescriptions found for user with ID: {}", id);
            return new ResponseEntity<>(allPrescriptionsById, HttpStatus.OK);
        } else {
            logger.error("Prescriptions not found for user with ID: {}", id);
            return new ResponseEntity<>(Map.of("error",
                    "No prescription found for user with ID " + id),
                    HttpStatus.NOT_FOUND);
        }
    }

}
