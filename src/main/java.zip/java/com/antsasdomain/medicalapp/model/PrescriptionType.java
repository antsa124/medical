package com.antsasdomain.medicalapp.model;

public enum PrescriptionType {

    E_REZEPT,
    PRIVAT,
    NONE

}
