package com.antsasdomain.medicalapp.model;

public enum AdminLevel {
    SUPER_ADMIN,
    MODERATOR,// can approve users for example
    NONE
}
