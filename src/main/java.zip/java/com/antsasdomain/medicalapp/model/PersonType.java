package com.antsasdomain.medicalapp.model;

public enum PersonType {
    DOCTOR,
    PATIENT,
    PHARMACIST,
    SUPER_ADMIN,
    MODERATOR,
    NONE
}
