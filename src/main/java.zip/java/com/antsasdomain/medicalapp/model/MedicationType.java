package com.antsasdomain.medicalapp.model;

public enum MedicationType {
    PILL,
    LIQUID,
    CREAM,
    INJECTION,
    INHALER,
    NONE
}
