package com.antsasdomain.medicalapp.service;

import com.antsasdomain.medicalapp.dto.address.AddressResponseDTO;
import com.antsasdomain.medicalapp.dto.doctorDTO.DoctorDTO;
import com.antsasdomain.medicalapp.dto.doctorDTO.DoctorUpdateDTO;
import com.antsasdomain.medicalapp.dto.doctorDTO.DoctorWithoutPrescriptionViewResponseDTO;
import com.antsasdomain.medicalapp.dto.medicationDTO.MedicationResponseDTO;
import com.antsasdomain.medicalapp.dto.patientDTO.PatientResponseDTO;
import com.antsasdomain.medicalapp.dto.prescriptionDTO.PrescriptionForDoctorResponseDTO;
import com.antsasdomain.medicalapp.model.*;
import com.antsasdomain.medicalapp.repository.DoctorRepository;
import com.antsasdomain.medicalapp.repository.PrescriptionRepository;
import com.antsasdomain.medicalapp.validation.EmailValidator;
import com.antsasdomain.medicalapp.validation.PasswordValidator;
import com.antsasdomain.medicalapp.validation.PhoneValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DoctorService {

    private static final Logger logger = LoggerFactory.getLogger(DoctorService.class);

    private final DoctorRepository doctorRepository;
    private final PrescriptionRepository prescriptionRepository;


    public DoctorService(
            DoctorRepository doctorRepository,
            PrescriptionRepository prescriptionRepository) {
        this.doctorRepository = doctorRepository;
        this.prescriptionRepository = prescriptionRepository;
    }

    public List<DoctorWithoutPrescriptionViewResponseDTO> findAll() {
        return doctorRepository.findAll().stream()
                .map(doctor -> new DoctorWithoutPrescriptionViewResponseDTO(
                        doctor.getUsername(),
                        doctor.getFirstName(),
                        doctor.getLastName(),
                        doctor.getEmail(),
                        doctor.getPhone(),
                        doctor.getOfficeName()
                ))
                .collect(Collectors.toList());
    }

    public DoctorWithoutPrescriptionViewResponseDTO findById(Integer id) {
        Optional<Doctor> doctor = doctorRepository.findById(id);

        return doctor.map(this::getNewDoctorResponse).orElse(null);
    }

    private ResponseEntity<?> mapNotEmpty(String param) {
        return new ResponseEntity<>
                (Map.of("error", param + " cannot be blank"),
                        HttpStatus.BAD_REQUEST);
    }

    private ResponseEntity<?> validateDoctor(DoctorDTO doctor) {

        if (doctor.getUsername().isBlank()) {
            return mapNotEmpty("Username");
        }

        if (doctor.getPassword().isBlank()) {
            return mapNotEmpty("Password");
        }

        if (!PasswordValidator.isValid(doctor.getPassword())) {
            return new ResponseEntity<>
                    (Map.of("error", "Password should be  at least 8 characters long, contain one" +
                            " uppercase letter, contain at least one number and at least one " +
                            "special character."),
                            HttpStatus.BAD_REQUEST);
        }

        if (doctor.getFirstName().isBlank()) {
            return mapNotEmpty("Firstname");
        }

        if (doctor.getLastName().isBlank()) {
            return mapNotEmpty("Lastname");
        }

        if (doctor.getEmail().isBlank()) {
            return mapNotEmpty("E-mail");
        }

        if (!EmailValidator.isValid(doctor.getEmail())) {
            return new ResponseEntity<>
                    (Map.of("error", "E-mail is not valid."),
                            HttpStatus.BAD_REQUEST);
        }

        if (doctor.getPhone().isBlank()) {
            return mapNotEmpty("Phone");
        }

        if (!PhoneValidator.isValid(doctor.getPhone())) {
            return new ResponseEntity<>
                    (Map.of("error", "phone should contain between 10 and 15 digits."),
                            HttpStatus.BAD_REQUEST);
        }

        if (doctor.getOfficeName().isBlank()) {
            return mapNotEmpty("Office Name");
        }

        return null;
    }

    private Doctor mapToDoctor(DoctorDTO doctor) {
        Doctor doctorEntity = new Doctor();

        doctorEntity.setPassword(doctor.getPassword());
        doctorEntity.setUsername(doctor.getUsername());
        doctorEntity.setPersonType(PersonType.DOCTOR);
        doctorEntity.setFirstName(doctor.getFirstName());
        doctorEntity.setLastName(doctor.getLastName());
        doctorEntity.setEmail(doctor.getEmail());
        doctorEntity.setPhone(doctor.getPhone());
        doctorEntity.setOfficeName(doctor.getOfficeName());
        doctorEntity.setPrescriptions(doctor.getPrescriptions());

        return doctorEntity;
    }


    public ResponseEntity<?> saveDoctor(DoctorDTO doctor) {

        ResponseEntity<?> responseEntity = validateDoctor(doctor);
        if (responseEntity != null) { // validation fail
            return responseEntity;
        }

        // transfer data to entity data
        Doctor doctorEntity = mapToDoctor(doctor);

        // Search first for already existing username and e-mail
        Optional<Doctor> doctorbyUsername = doctorRepository.findByUsername(doctor.getUsername());
        if (doctorbyUsername.isPresent()) {
            return new ResponseEntity<>
                    (Map.of("error",
                            "Doctor with username '" + doctorbyUsername.get().getUsername() + "' already exists"),
                            HttpStatus.CONFLICT);
        }
        Optional<Doctor> doctorByEmail = doctorRepository.findByEmail(doctor.getEmail());
        if (doctorByEmail.isPresent()) {
            return new ResponseEntity<>
                    (Map.of("error",
                            "Doctor with e-mail address '" + doctorByEmail.get().getEmail() + "' " +
                                    "already exists."),
                            HttpStatus.CONFLICT);
        }

        Doctor savedDoctor = doctorRepository.save(doctorEntity);

        // return user without showing password or id
        return ResponseEntity.ok(getNewDoctorResponse(savedDoctor));
    }

    public ResponseEntity<?> deleteById(Integer id) {
        DoctorWithoutPrescriptionViewResponseDTO byId = findById(id);
        if (byId != null) {
            doctorRepository.deleteById(id);
            return new ResponseEntity<>(Map.of("message", "Doctor deleted successfully"),
                    HttpStatus.OK);
        } else {
            return new ResponseEntity<>(Map.of("error", "User with ID " + id + " not found."),
                    HttpStatus.NOT_FOUND);
        }
    }

    public DoctorWithoutPrescriptionViewResponseDTO update(
            Doctor doctorEntity,
            DoctorUpdateDTO doctorDTO) {

        if (doctorDTO.getUsername() != null) {
            doctorEntity.setUsername(doctorDTO.getUsername());
        }
        if (doctorDTO.getPassword() != null) {
            doctorEntity.setPassword(doctorDTO.getPassword());
        }
        if (doctorDTO.getFirstName() != null) {
            doctorEntity.setFirstName(doctorDTO.getFirstName());
        }
        if (doctorDTO.getLastName() != null) {
            doctorEntity.setLastName(doctorDTO.getLastName());
        }
        if (doctorDTO.getEmail() != null) {
            doctorEntity.setEmail(doctorDTO.getEmail());
        }
        if (doctorDTO.getPhone() != null) {
            doctorEntity.setPhone(doctorDTO.getPhone());
        }
        if (doctorDTO.getOfficeName() != null) {
            doctorEntity.setOfficeName(doctorDTO.getOfficeName());
        }
        if (doctorDTO.getPrescriptions() != null) {
            doctorEntity.setPrescriptions(doctorDTO.getPrescriptions());
        }

        doctorRepository.save(doctorEntity);

        return getNewDoctorResponse(doctorEntity);
    }

    public ResponseEntity<?> getPrescriptionById(Integer doctorId, Integer prescriptionId) {
        Optional<Doctor> doctor = doctorRepository.findById(doctorId);

        if (doctor.isPresent()) {
            Optional<Prescription> byIdAndDoctor = prescriptionRepository.findByIdAndDoctor(prescriptionId, doctor.get());
            if (byIdAndDoctor.isPresent()) {
                return ResponseEntity.ok(byIdAndDoctor.get());
            } else {
                return new ResponseEntity<>
                        (Map.of("error", "No prescription linked by doctor."), HttpStatus.NOT_FOUND);
            }
        } else {
            return new ResponseEntity<>
                    (Map.of("error", "No doctor with ID " + doctorId + " found."),
                     HttpStatus.NOT_FOUND);
        }
    }

    public ResponseEntity<?> cancelPrescriptionById(Integer doctorId, Integer prescriptionId) {
        Optional<Doctor> doctor = doctorRepository.findById(doctorId);
        if (doctor.isPresent()) {
            Optional<Prescription> prescription =
                    prescriptionRepository.findByIdAndDoctor(prescriptionId, doctor.get());
            if (prescription.isPresent()) {
                if (PrescriptionStatus.CANCELED.equals(prescription.get().getPrescriptionStatus())) {
                    return new ResponseEntity<>
                            (Map.of("error", "Prescription is already cancelled."),
                                    HttpStatus.OK);
                } else {
                    prescription.get().setPrescriptionStatus(PrescriptionStatus.CANCELED);
                    Prescription savedPrescription = prescriptionRepository.save(prescription.get());
                    // TODO mapping
                    return new ResponseEntity<>(savedPrescription, HttpStatus.OK);
                }
            } else {
                return new ResponseEntity<>
                        (Map.of("error", "No prescription linked to doctor found."),
                         HttpStatus.NOT_FOUND);
            }
        } else {
            return new ResponseEntity<>
                    (Map.of("error", "No doctor with ID " + doctorId + " found."),
                     HttpStatus.NOT_FOUND);
        }
    }

    public ResponseEntity<?> getPrescriptionsByDoctorId(Integer id) {
        Optional<Doctor> doctorById = doctorRepository.findById(id);

        if (doctorById.isPresent()) {
            List<Prescription> prescriptionsByDoctor = prescriptionRepository.findByDoctor(doctorById.get());
            if (!prescriptionsByDoctor.isEmpty()) {
                List<PrescriptionForDoctorResponseDTO> responseList = prescriptionsByDoctor.stream()
                        .map(prescription -> {

                            Patient patient = prescription.getPatient();
                            Address address = patient.getAddress();

                            AddressResponseDTO addressDTO = mapToAddressResponseDTO(address);

                            PatientResponseDTO userDto = mapToUserResponseDTO(patient, addressDTO);

                            List<MedicationResponseDTO> medicationResponseDTOs = new ArrayList<>();
                            for (Medication medication : prescription.getMedicine()) {
                                MedicationResponseDTO medicationDTO = new MedicationResponseDTO(
                                        medication.getName(),
                                        medication.getDescription(),
                                        medication.getDosage(),
                                        medication.getMedicationType()
                                );
                                medicationResponseDTOs.add(medicationDTO);
                            }

                            return mapToPrescriptionResponseDTO(
                                    userDto, prescription, medicationResponseDTOs);
                        }).toList();

                return new ResponseEntity<>(responseList, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(
                        Map.of("message", "No prescriptions found for Doctor with ID: " + id),
                        HttpStatus.NOT_FOUND);
            }

        } else {
            return new ResponseEntity<>(Map.of("error", "Doctor with id '" + id + "' does not exists"), HttpStatus.NOT_FOUND);
        }
    }

    private AddressResponseDTO mapToAddressResponseDTO(Address address) {
        return new AddressResponseDTO(
                address.getStreet(),
                address.getCity(),
                address.getState(),
                address.getZipCode(),
                address.getCountry());
    }

    private PatientResponseDTO mapToUserResponseDTO(Patient patient, AddressResponseDTO addressDTO) {
        return new PatientResponseDTO(
                patient.getUsername(),
                patient.getFirstName(),
                patient.getLastName(),
                patient.getEmail(),
                patient.getPhone(),
                addressDTO,
                patient.getBirthday(),
                patient.getPatientInsuranceNumber()
        );
    }

    private PrescriptionForDoctorResponseDTO mapToPrescriptionResponseDTO (
            PatientResponseDTO userDto,
            Prescription prescription,
            List<MedicationResponseDTO> medicationResponseDTOs) {
        return new PrescriptionForDoctorResponseDTO(
                userDto,
                prescription.getPrescriptionDate(),
                prescription.getPrescriptionType(),
                medicationResponseDTOs,
                prescription.getQrCodes(),
                prescription.getPharmacyCode()
        );
    }

    private DoctorWithoutPrescriptionViewResponseDTO getNewDoctorResponse(Doctor doctor) {
        return new DoctorWithoutPrescriptionViewResponseDTO(
                doctor.getUsername(),
                doctor.getFirstName(),
                doctor.getLastName(),
                doctor.getEmail(),
                doctor.getPhone(),
                doctor.getOfficeName());
    }

    public Doctor getUserWithId(Integer id) {
        return doctorRepository.findById(id).orElse(null);
    }

}
