package com.antsasdomain.medicalapp.service;

import com.antsasdomain.medicalapp.dto.address.AddressDTO;
import com.antsasdomain.medicalapp.dto.auth.RegistrationDTO;
import com.antsasdomain.medicalapp.model.*;
import com.antsasdomain.medicalapp.repository.DoctorRepository;
import com.antsasdomain.medicalapp.repository.PatientRepository;
import com.antsasdomain.medicalapp.repository.PersonRepository;
import com.antsasdomain.medicalapp.repository.PharmacistRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;

@Service
public class AuthService {

    private final PersonRepository personRepository;
    private final DoctorRepository doctorRepository;
    private final PharmacistRepository pharmacistRepository;
    private final PatientRepository patientRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthService(
            PersonRepository personRepository,
            DoctorRepository doctorRepository,
            PharmacistRepository pharmacistRepository,
            PatientRepository patientRepository,
            PasswordEncoder passwordEncoder) {
        this.personRepository = personRepository;
        this.doctorRepository = doctorRepository;
        this.pharmacistRepository = pharmacistRepository;
        this.patientRepository = patientRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public ResponseEntity<?> registerNewPerson(RegistrationDTO registrationDTO) {
        Optional<Person> byUsername = personRepository.findByUsername(registrationDTO.getUsername());
        if (byUsername.isPresent()) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Username already exists. Please choose something else" +
                            "."));
        }
        Optional<Person> byEmail = personRepository.findByEmail(registrationDTO.getEmail());
        if (byEmail.isPresent()) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "E-Mail already exists. Please choose something else"));
        }

        PersonType personType;

        try {
            personType = PersonType.valueOf(String.valueOf(registrationDTO.getPersonType()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity
                    .badRequest()
                    .body(Map.of("error", "Invalid person type. Choose from: DOCTOR, PHARMACIST, " +
                            "PATIENT."));
        }

        // Hash password before saving
        String hashedPassword = passwordEncoder.encode(registrationDTO.getPassword());

        switch (personType) {
            case DOCTOR:
                return mapToDoctor(registrationDTO, hashedPassword);
            case PHARMACIST:
                return mapToPharmacist(registrationDTO, hashedPassword);
            case PATIENT:
                return mapToPatient(registrationDTO, hashedPassword);
        }

        return ResponseEntity
                .badRequest()
                .body(Map.of("error", "Invalid request."));
    }

    private ResponseEntity<?> mapToDoctor(RegistrationDTO registrationDTO, String hashedPassword) {
        if (registrationDTO.getOfficeName() == null) {
            return ResponseEntity
                    .badRequest()
                    .body(Map.of("Error", "Missing required field 'officeName' for doctors."));
        }
        Doctor doctor = new Doctor(
                registrationDTO.getUsername(),
                hashedPassword,
                registrationDTO.getFirstName(),
                registrationDTO.getLastName(),
                registrationDTO.getEmail(),
                registrationDTO.getPhone(),
                registrationDTO.getOfficeName()
        );
        doctorRepository.save(doctor);
        return ResponseEntity.ok(Map.of("success", "Doctor registered successfully! " +
                "Awaiting admin approval."));
    }

    private ResponseEntity<?> mapToPharmacist(RegistrationDTO registrationDTO,
                                            String hashedPassword) {
        if (registrationDTO.getPharmacyName() == null || registrationDTO.getPharmacyCode() == null) {
            return ResponseEntity
                    .badRequest()
                    .body(Map.of("error", "Missing required fields 'pharmacyName' or " +
                            "'pharmacyCode' for pharmacists."));
        }
        Pharmacist pharmacist = new Pharmacist(
                registrationDTO.getUsername(),
                hashedPassword,
                registrationDTO.getFirstName(),
                registrationDTO.getLastName(),
                registrationDTO.getEmail(),
                registrationDTO.getPhone(),
                registrationDTO.getPharmacyName(),
                registrationDTO.getPharmacyCode()
        );
        pharmacistRepository.save(pharmacist);
        return ResponseEntity.
                ok(Map.of("success","Pharmacist registered successfully! Awaiting admin " +
                        "approval."));
    }

    private ResponseEntity<?> mapToPatient(RegistrationDTO registrationDTO, String hashedPassword) {
        if (registrationDTO.getAddress() == null) {
            return ResponseEntity
                    .badRequest()
                    .body(Map.of("error",  "Missing required patient address."));
        }
        if (registrationDTO.getBirthday() == null) {
            return ResponseEntity
                    .badRequest()
                    .body(Map.of("error",  "Missing required patient birthdate."));
        }
        if (registrationDTO.getPatientInsuranceNumber() == null) {
            return ResponseEntity
                    .badRequest()
                    .body(Map.of("error",  "Missing required patient insurance number."));
        }

        //String street, String city, String state, String zipCode, String country
        AddressDTO addressDTO = registrationDTO.getAddress();

        Address patientAddress = new Address(
                addressDTO.getStreet(),
                addressDTO.getCity(),
                addressDTO.getState(),
                addressDTO.getZipCode(),
                addressDTO.getCountry()
        );

        Patient patient = new Patient(
                registrationDTO.getUsername(),
                hashedPassword,
                registrationDTO.getFirstName(),
                registrationDTO.getLastName(),
                registrationDTO.getEmail(),
                registrationDTO.getPhone(),
                patientAddress,
                registrationDTO.getBirthday(),
                registrationDTO.getPatientInsuranceNumber());
        patient.setApproved(true); // Patients are automatically approved
        patientRepository.save(patient);
        return ResponseEntity.ok("Patient registered successfully!");
    }
}
