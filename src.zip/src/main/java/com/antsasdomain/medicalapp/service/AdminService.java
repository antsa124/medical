package com.antsasdomain.medicalapp.service;

import com.antsasdomain.medicalapp.model.Person;
import com.antsasdomain.medicalapp.repository.PersonRepository;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

    private final PersonRepository personRepository;

    public AdminService(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    public String approveUser(Integer userId) {
        Person user = personRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        user.setApproved(true);
        personRepository.save(user);
        return "User with id " + userId + " has been approved";
    }
}
