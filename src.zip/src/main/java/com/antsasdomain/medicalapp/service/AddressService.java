package com.antsasdomain.medicalapp.service;

import com.antsasdomain.medicalapp.model.Address;
import com.antsasdomain.medicalapp.repository.AddressRepository;
import org.springframework.stereotype.Service;

@Service
public class AddressService {

    private AddressRepository addressRepository;

    public AddressService(AddressRepository addressRepository) {
        this.addressRepository = addressRepository;
    }

    public Address save(Address address) {
        return addressRepository.save(address);
    }
}
