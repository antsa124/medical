package com.antsasdomain.medicalapp.dto.auth;


import com.antsasdomain.medicalapp.dto.address.AddressDTO;
import com.antsasdomain.medicalapp.model.PersonType;
import com.antsasdomain.medicalapp.validation.ValidInsuranceNumber;
import com.antsasdomain.medicalapp.validation.ValidPassword;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class RegistrationDTO {
    @NotBlank(message = "Username cannot be empty")
    @Size(min = 4, max = 20, message = "Username must be 4-20 characters long")
    private String username;

    @ValidPassword
    @NotBlank(message = "Password cannot be empty")
    private String password;

    @NotBlank(message = "First name cannot be empty")
    private String firstName;

    @NotBlank(message = "Last name cannot be empty")
    private String lastName;

    @Email(message = "Invalid email format")
    @NotBlank(message = "Email cannot be empty")
    private String email;

    @NotBlank(message = "Phone cannot be empty")
    private String phone;

    @NotNull(message = "Must chooses between 'DOCTOR', 'PHARMACIST', 'PATIENT'")
    private PersonType personType; // "DOCTOR", "PHARMACIST", "PATIENT"

    private String officeName; // case DOCTOR

    private String pharmacyName; // case PHARMACIST
    private String pharmacyCode; // case PHARMACIST

    // case PATIENT - TODO
    private AddressDTO address;
    private LocalDate birthday;
    private String patientInsuranceNumber;
}

