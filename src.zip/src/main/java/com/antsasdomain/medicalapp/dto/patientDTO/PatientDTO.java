package com.antsasdomain.medicalapp.dto.patientDTO;

import com.antsasdomain.medicalapp.dto.AbstractPersonDTO;
import com.antsasdomain.medicalapp.dto.address.AddressDTO;
import com.antsasdomain.medicalapp.validation.ValidInsuranceNumber;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PatientDTO extends AbstractPersonDTO {

    @Valid
    private AddressDTO address;

    @Past(message = "Birthday must be a past date")
    @NotNull(message = "Birthday cannot be empty")
    private LocalDate birthday;

    @NotBlank(message = "Patient Insurance Number cannot be empty")
    @ValidInsuranceNumber
    private String patientInsuranceNumber;

    public PatientDTO(
            String username,
            String password,
            String firstName,
            String lastName,
            String email,
            String phone,
            AddressDTO address,
            LocalDate birthday,
            String patientInsuranceNumber) {
        super(username, password, firstName, lastName, email, phone);
        this.address = address;
        this.birthday = birthday;
        this.patientInsuranceNumber = patientInsuranceNumber;
    }
}
