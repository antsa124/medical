package com.antsasdomain.medicalapp.dto.doctorDTO;

import com.antsasdomain.medicalapp.dto.AbstractUpdatePersonDTO;
import com.antsasdomain.medicalapp.model.Prescription;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DoctorUpdateDTO extends AbstractUpdatePersonDTO {

    private String officeName;
    private List<Prescription> prescriptions;
}
