package com.antsasdomain.medicalapp.dto.prescriptionDTO;

import com.antsasdomain.medicalapp.dto.MedicationDTO;
import com.antsasdomain.medicalapp.dto.doctorDTO.DoctorDTO;
import com.antsasdomain.medicalapp.dto.patientDTO.PatientDTO;
import com.antsasdomain.medicalapp.model.*;
import com.antsasdomain.medicalapp.validation.PrescriptionStatusDeserializer;
import com.antsasdomain.medicalapp.validation.PrescriptionTypeDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PrescriptionDTO {
    @NotNull(message = "Prescription must have patient information")
    private PatientDTO patient;
    @NotNull(message = "Doctor information should be provided")
    private DoctorDTO doctor;
    @NotBlank(message = "Patient insurance number must be given")
    private String patientInsuranceNumber;
    @NotNull(message = "prescription date must be given")// Versichertern-Nr
    private LocalDate prescriptionDate;

    @NotNull(message = "Prescription type must be given")
    @JsonDeserialize(using = PrescriptionTypeDeserializer.class)
    private PrescriptionType prescriptionType;

    @NotNull(message = "Medicine cannot be empty")
    private List<MedicationDTO> medicine;
    @NotNull(message = "QR Codes cannot be null")
    private List<String> qrCodes;
    @NotBlank(message = "pharmacy code must be provided")
    private String pharmacyCode;

    @JsonDeserialize(using = PrescriptionStatusDeserializer.class)
    private PrescriptionStatus prescriptionStatus;
}
