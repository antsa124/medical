package com.antsasdomain.medicalapp.config;

import com.antsasdomain.medicalapp.service.PersonDetailsService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import java.util.List;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration // ✅ This tells Spring it's a configuration class
@EnableWebSecurity // ✅ Enables Spring Security
public class SecurityConfig {

    private final PersonDetailsService personDetailsService;

    public SecurityConfig(PersonDetailsService personDetailsService) {
        this.personDetailsService = personDetailsService;
    }

    /** ✅ Password Encoder Bean (Used to hash & verify passwords) */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /** ✅ Define Authentication Provider (UserDetailsService + Password Encoder) */
    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(personDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    /** ✅ Fix AuthenticationManager Bean (Ensures it works in AuthController) */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return new ProviderManager(List.of(authenticationProvider())); // Uses our custom provider
    }

    /** ✅ Security Filter Chain (Authorization rules) */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/auth/**").permitAll()  // Allow login & register
                        .requestMatchers("/api/admin/**").hasRole("ADMIN") // Only admins can access
                        .requestMatchers("/api/doctors/**").hasRole("DOCTOR") // Only doctors can access
                        .requestMatchers("/api/pharmacists/**").hasRole("PHARMACIST") // Only pharmacists can access
                        .requestMatchers("/api/patients/**").hasRole("PATIENT") // Only patients can access
                        .anyRequest().authenticated()
                )
                .csrf(AbstractHttpConfigurer::disable) // Disable CSRF for simplicity
                .authenticationProvider(authenticationProvider()) // Ensures authentication works
                .httpBasic(withDefaults());

        return http.build();
    }
}
