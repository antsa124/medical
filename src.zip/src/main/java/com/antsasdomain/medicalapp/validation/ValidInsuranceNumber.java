package com.antsasdomain.medicalapp.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = InsuranceNumberValidator.class)
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidInsuranceNumber {

    String message() default "Invalid insurance number";

    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
