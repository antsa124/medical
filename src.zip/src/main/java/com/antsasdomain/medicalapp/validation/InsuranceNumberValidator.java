package com.antsasdomain.medicalapp.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class InsuranceNumberValidator implements ConstraintValidator<ValidInsuranceNumber, String> {

    private static final String REGEX_PATTERN = "^[A-Z]\\d{9}$";
    @Override
    public boolean isValid(String insuranceNumber,
                           ConstraintValidatorContext constraintValidatorContext) {
        if (insuranceNumber == null) {
            return false;
        }

        // Matches: "A123456789" or "A12345678901" for example for Insurance Number law
        return insuranceNumber.matches("^[A-Z]\\d{9}$")
                || insuranceNumber.matches("^[A-Z]\\d{11}$");
    }
}




